package com.ense374;


import java.util.Scanner;
import java.util.InputMismatchException;
/**
 *
 * @author labatetk
 */
public class EmployeeTest {

public static void main(String[] args) {
		
		Employee[] employeeList = new Employee[3];
        
		CommandLineInterface cli = new CommandLineInterface();
	
		Scanner input = new Scanner(System.in);
		
		
		
		/* Test 1  Verify that can handle all input from the user */
		
		boolean doneTest1 = false;
		String doneTest1Flag;
		
		do {
			try{
			int choice = cli.getMainMenuNumber();
			System.out.println(choice);
			
			System.out.println("Are We done test 1? Y/N");
			doneTest1Flag = input.nextLine();
			if(doneTest1Flag.equals("Y"))
			{
				doneTest1 = true;
			}
			}
			catch(InputMismatchException ex){
				System.out.println("Exception thrown:" +ex);
			}
		} while (!doneTest1);
		
		/* Test 2 Pass in bad values for an employee*/
		//Pass in some bad data to the salary to ensure it can be handled
		
		Employee employee = cli.getEmployeeDataFromCLI();
            
			
		
		/* Test 3 Read in a file containing Employee Data */
		
		System.out.println("Reading in data: " + cli.readInEmployeeData("employe.csv", employeeList));
		
		System.out.println("All tests pass!");
		
	}

}
